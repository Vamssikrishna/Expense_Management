import React from 'react';

const SubmitExpense = () => (
  <div className="max-w-4xl mx-auto">
    <h1 className="text-3xl font-bold text-gray-900 mb-8">Submit Expense</h1>
    <div className="bg-white rounded-lg shadow-sm border p-8">
      <p className="text-gray-600">Expense submission form will be implemented here.</p>
      <p className="text-sm text-gray-500 mt-2">
        Features: OCR receipt scanning, automatic currency conversion, multi-category support
      </p>
    </div>
  </div>
);

export default SubmitExpense;



