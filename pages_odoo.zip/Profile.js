import React, { useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';
import { useAuth } from '../context/AuthContext';
import toast from 'react-hot-toast';

const Profile = () => {
  const { user, updateProfile, changePassword } = useAuth();

  const [activeTab, setActiveTab] = useState('profile');
  const [savingPrefs, setSavingPrefs] = useState(false);

  // Notification preferences stored locally (no dedicated backend endpoint)
  const [preferences, setPreferences] = useState({
    emailNotifications: true,
    pushNotifications: false,
    weeklySummary: true
  });

  useEffect(() => {
    const saved = localStorage.getItem('ems_notifications');
    if (saved) {
      try {
        setPreferences(JSON.parse(saved));
      } catch (_) {
        // ignore parse errors
      }
    }
  }, []);

  const {
    register: registerProfile,
    handleSubmit: handleSubmitProfile,
    reset: resetProfile,
    formState: { errors: profileErrors, isSubmitting: profileSubmitting }
  } = useForm({
    defaultValues: {
      name: user?.name || '',
      phoneNumber: user?.phoneNumber || '',
      department: user?.department || '',
      jobTitle: user?.jobTitle || '',
      profilePicture: user?.profilePicture || ''
    }
  });

  useEffect(() => {
    resetProfile({
      name: user?.name || '',
      phoneNumber: user?.phoneNumber || '',
      department: user?.department || '',
      jobTitle: user?.jobTitle || '',
      profilePicture: user?.profilePicture || ''
    });
  }, [user, resetProfile]);

  const {
    register: registerPassword,
    handleSubmit: handleSubmitPassword,
    reset: resetPassword,
    watch: watchPassword,
    formState: { errors: passwordErrors, isSubmitting: passwordSubmitting }
  } = useForm({
    defaultValues: {
      currentPassword: '',
      newPassword: '',
      confirmNewPassword: ''
    }
  });

  const onSubmitProfile = async (data) => {
    const payload = {
      name: data.name?.trim(),
      phoneNumber: data.phoneNumber?.trim() || undefined,
      department: data.department?.trim() || undefined,
      jobTitle: data.jobTitle?.trim() || undefined,
      profilePicture: data.profilePicture?.trim() || undefined
    };

    const result = await updateProfile(payload);
    if (result?.success) {
      toast.success('Profile details updated');
    }
  };

  const onSubmitPassword = async (data) => {
    if (data.newPassword !== data.confirmNewPassword) {
      toast.error('New password and confirmation do not match');
      return;
    }
    const result = await changePassword({
      currentPassword: data.currentPassword,
      newPassword: data.newPassword
    });
    if (result?.success) {
      resetPassword();
    }
  };

  const savePreferences = async () => {
    setSavingPrefs(true);
    try {
      localStorage.setItem('ems_notifications', JSON.stringify(preferences));
      toast.success('Notification preferences saved');
    } finally {
      setSavingPrefs(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto">
      <h1 className="text-3xl font-bold text-gray-900 mb-8">Profile Settings</h1>

      {/* Tabs */}
      <div className="mb-6 border-b border-gray-200">
        <nav className="-mb-px flex space-x-6" aria-label="Tabs">
          <button
            onClick={() => setActiveTab('profile')}
            className={`${activeTab === 'profile' ? 'border-blue-600 text-blue-600' : 'border-transparent text-gray-500 hover:text-gray-700'} whitespace-nowrap py-4 px-1 border-b-2 text-sm font-medium`}
          >
            Profile
          </button>
          <button
            onClick={() => setActiveTab('security')}
            className={`${activeTab === 'security' ? 'border-blue-600 text-blue-600' : 'border-transparent text-gray-500 hover:text-gray-700'} whitespace-nowrap py-4 px-1 border-b-2 text-sm font-medium`}
          >
            Security
          </button>
          <button
            onClick={() => setActiveTab('notifications')}
            className={`${activeTab === 'notifications' ? 'border-blue-600 text-blue-600' : 'border-transparent text-gray-500 hover:text-gray-700'} whitespace-nowrap py-4 px-1 border-b-2 text-sm font-medium`}
          >
            Notifications
          </button>
        </nav>
      </div>

      {/* Profile Info */}
      {activeTab === 'profile' && (
        <div className="bg-white rounded-lg shadow-sm border p-6">
          <form onSubmit={handleSubmitProfile(onSubmitProfile)} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700">Full Name *</label>
                <input
                  type="text"
                  className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2 focus:ring-blue-500 focus:border-blue-500"
                  {...registerProfile('name', {
                    required: 'Name is required',
                    minLength: { value: 2, message: 'Name must be at least 2 characters' },
                    maxLength: { value: 50, message: 'Name cannot exceed 50 characters' }
                  })}
                />
                {profileErrors.name && (
                  <p className="mt-1 text-sm text-red-600">{profileErrors.name.message}</p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Phone Number</label>
                <input
                  type="text"
                  className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2 focus:ring-blue-500 focus:border-blue-500"
                  placeholder="e.g., +1234567890"
                  {...registerProfile('phoneNumber', {
                    pattern: {
                      value: /^[+]?[1-9][\d]{0,15}$/,
                      message: 'Please provide a valid phone number'
                    }
                  })}
                />
                {profileErrors.phoneNumber && (
                  <p className="mt-1 text-sm text-red-600">{profileErrors.phoneNumber.message}</p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Department</label>
                <input
                  type="text"
                  className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2 focus:ring-blue-500 focus:border-blue-500"
                  {...registerProfile('department', {
                    maxLength: { value: 50, message: 'Department cannot exceed 50 characters' }
                  })}
                />
                {profileErrors.department && (
                  <p className="mt-1 text-sm text-red-600">{profileErrors.department.message}</p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Job Title</label>
                <input
                  type="text"
                  className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2 focus:ring-blue-500 focus:border-blue-500"
                  {...registerProfile('jobTitle', {
                    maxLength: { value: 50, message: 'Job title cannot exceed 50 characters' }
                  })}
                />
                {profileErrors.jobTitle && (
                  <p className="mt-1 text-sm text-red-600">{profileErrors.jobTitle.message}</p>
                )}
              </div>

              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-gray-700">Profile Picture URL</label>
                <input
                  type="url"
                  className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2 focus:ring-blue-500 focus:border-blue-500"
                  placeholder="https://..."
                  {...registerProfile('profilePicture', {
                    pattern: {
                      value: /^(https?:\/\/).+/i,
                      message: 'Please provide a valid URL'
                    }
                  })}
                />
                {profileErrors.profilePicture && (
                  <p className="mt-1 text-sm text-red-600">{profileErrors.profilePicture.message}</p>
                )}
              </div>
            </div>

            <div className="flex justify-end">
              <button
                type="submit"
                disabled={profileSubmitting}
                className="btn btn-primary"
              >
                {profileSubmitting ? 'Saving...' : 'Save Changes'}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Security */}
      {activeTab === 'security' && (
        <div className="bg-white rounded-lg shadow-sm border p-6">
          <form onSubmit={handleSubmitPassword(onSubmitPassword)} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-gray-700">Current Password *</label>
                <input
                  type="password"
                  className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2 focus:ring-blue-500 focus:border-blue-500"
                  {...registerPassword('currentPassword', { required: 'Current password is required' })}
                />
                {passwordErrors.currentPassword && (
                  <p className="mt-1 text-sm text-red-600">{passwordErrors.currentPassword.message}</p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">New Password *</label>
                <input
                  type="password"
                  className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2 focus:ring-blue-500 focus:border-blue-500"
                  {...registerPassword('newPassword', {
                    required: 'New password is required',
                    minLength: { value: 6, message: 'Password must be at least 6 characters' },
                    pattern: {
                      value: /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/,
                      message: 'Password must contain uppercase, lowercase, and number'
                    }
                  })}
                />
                {passwordErrors.newPassword && (
                  <p className="mt-1 text-sm text-red-600">{passwordErrors.newPassword.message}</p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Confirm New Password *</label>
                <input
                  type="password"
                  className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2 focus:ring-blue-500 focus:border-blue-500"
                  {...registerPassword('confirmNewPassword', {
                    required: 'Please confirm new password',
                    validate: (value) => value === watchPassword('newPassword') || 'Passwords do not match'
                  })}
                />
                {passwordErrors.confirmNewPassword && (
                  <p className="mt-1 text-sm text-red-600">{passwordErrors.confirmNewPassword.message}</p>
                )}
              </div>
            </div>

            <div className="flex justify-end">
              <button
                type="submit"
                disabled={passwordSubmitting}
                className="btn btn-primary"
              >
                {passwordSubmitting ? 'Changing...' : 'Change Password'}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Notifications */}
      {activeTab === 'notifications' && (
        <div className="bg-white rounded-lg shadow-sm border p-6 space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-900">Email notifications</p>
              <p className="text-sm text-gray-500">Receive updates about approvals and activity via email.</p>
            </div>
            <label className="inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                className="sr-only"
                checked={preferences.emailNotifications}
                onChange={(e) => setPreferences({ ...preferences, emailNotifications: e.target.checked })}
              />
              <span className={`w-11 h-6 flex items-center bg-${preferences.emailNotifications ? 'blue' : 'gray'}-200 rounded-full p-1`}> 
                <span className={`bg-white w-4 h-4 rounded-full shadow transform transition ${preferences.emailNotifications ? 'translate-x-5' : ''}`}></span>
              </span>
            </label>
          </div>

          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-900">Push notifications</p>
              <p className="text-sm text-gray-500">Real-time desktop notifications for requests and status changes.</p>
            </div>
            <label className="inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                className="sr-only"
                checked={preferences.pushNotifications}
                onChange={(e) => setPreferences({ ...preferences, pushNotifications: e.target.checked })}
              />
              <span className={`w-11 h-6 flex items-center bg-${preferences.pushNotifications ? 'blue' : 'gray'}-200 rounded-full p-1`}>
                <span className={`bg-white w-4 h-4 rounded-full shadow transform transition ${preferences.pushNotifications ? 'translate-x-5' : ''}`}></span>
              </span>
            </label>
          </div>

          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-900">Weekly summary</p>
              <p className="text-sm text-gray-500">Get a weekly summary of expenses and approvals.</p>
            </div>
            <label className="inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                className="sr-only"
                checked={preferences.weeklySummary}
                onChange={(e) => setPreferences({ ...preferences, weeklySummary: e.target.checked })}
              />
              <span className={`w-11 h-6 flex items-center bg-${preferences.weeklySummary ? 'blue' : 'gray'}-200 rounded-full p-1`}>
                <span className={`bg-white w-4 h-4 rounded-full shadow transform transition ${preferences.weeklySummary ? 'translate-x-5' : ''}`}></span>
              </span>
            </label>
          </div>

          <div className="flex justify-end">
            <button
              onClick={savePreferences}
              disabled={savingPrefs}
              className="btn btn-primary"
            >
              {savingPrefs ? 'Saving...' : 'Save Preferences'}
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default Profile;