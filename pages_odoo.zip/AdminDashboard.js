import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from 'react-query';
import axios from 'axios';
import { useAuth } from '../context/AuthContext';
import toast from 'react-hot-toast';
import {
  Users,
  Plus,
  Settings,
  BarChart3,
  CheckCircle,
  Clock,
  TrendingUp,
  Building2,
  UserPlus,
  Shield
} from 'lucide-react';
import UserManagementModal from '../components/UserManagementModal';

const AdminDashboard = () => {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const [showUserModal, setShowUserModal] = useState(false);
  const [editingUser, setEditingUser] = useState(null);

  // Fetch dashboard statistics from API
  const { data: stats, isLoading: statsLoading } = useQuery(
    'admin-dashboard-stats',
    () => axios.get('/api/approvals/stats').then(res => res.data.data),
    {
      enabled: !!user,
      retry: 1
    }
  );

  // Fetch all users from API
  const { data: usersData, isLoading: usersLoading } = useQuery(
    'company-users',
    () => axios.get('/api/users/all').then(res => res.data),
    {
      enabled: !!user,
      retry: 1,
      onError: (error) => {
        console.error('Failed to fetch users:', error);
        // Fallback to mock data if API fails
        return {
          data: [
            {
              _id: '1',
              name: 'vamsi krishna',
              email: 'vamsikrishnaakk@gmail.com',
              role: 'Admin',
              department: 'Management',
              isActive: true
            },
            {
              _id: '2',
              name: 'John Smith',
              email: 'john@company.com',
              role: 'Manager',
              department: 'Engineering',
              isActive: true
            },
            {
              _id: '3',
              name: 'Sarah Johnson',
              email: 'sarah@company.com',
              role: 'Employee',
              department: 'Marketing',
              isActive: true
            }
          ]
        };
      }
    }
  );

  // Fetch all company expenses from API
  const { data: expensesData, isLoading: expensesLoading } = useQuery(
    'company-expenses',
    () => axios.get('/api/expenses/admin/all').then(res => res.data),
    {
      enabled: !!user,
      retry: 1,
      onError: (error) => {
        console.error('Failed to fetch expenses:', error);
        // Fallback to mock data if API fails
        return {
          data: [
            {
              _id: '1',
              description: 'Travel to client meeting',
              category: 'Travel',
              amount: 450,
              currency: 'USD',
              convertedAmount: 450,
              status: 'Approved',
              date: new Date().toISOString(),
              employeeId: { name: 'John Smith' },
              companyId: { currency: 'USD' }
            },
            {
              _id: '2',
              description: 'Office supplies',
              category: 'Office Supplies',
              amount: 125,
              currency: 'USD',
              convertedAmount: 125,
              status: 'Pending',
              date: new Date().toISOString(),
              employeeId: { name: 'Sarah Johnson' },
              companyId: { currency: 'USD' }
            }
          ]
        };
      }
    }
  );

  const handleAddUser = () => {
    setEditingUser(null);
    setShowUserModal(true);
  };

  const handleEditUser = (userData) => {
    setEditingUser(userData);
    setShowUserModal(true);
  };

  const handleCloseModal = () => {
    setShowUserModal(false);
    setEditingUser(null);
  };

  // Deactivate user mutation
  const deactivateUserMutation = useMutation(
    (userId) => axios.put(`/api/users/${userId}`, { isActive: false }),
    {
      onSuccess: () => {
        queryClient.invalidateQueries('company-users');
        toast.success('User deactivated successfully!');
      },
      onError: (error) => {
        toast.error(error.response?.data?.message || 'Failed to deactivate user');
      }
    }
  );

  const handleDeactivateUser = (userId, userName) => {
    if (window.confirm(`Are you sure you want to deactivate ${userName}?`)) {
      deactivateUserMutation.mutate(userId);
    }
  };

  // Reactivate user mutation
  const reactivateUserMutation = useMutation(
    (userId) => axios.put(`/api/users/${userId}`, { isActive: true }),
    {
      onSuccess: () => {
        queryClient.invalidateQueries('company-users');
        toast.success('User reactivated successfully!');
      },
      onError: (error) => {
        toast.error(error.response?.data?.message || 'Failed to reactivate user');
      }
    }
  );

  const handleReactivateUser = (userId, userName) => {
    if (window.confirm(`Are you sure you want to reactivate ${userName}?`)) {
      reactivateUserMutation.mutate(userId);
    }
  };

  const StatCard = ({ title, value, icon: Icon, color = 'blue', trend }) => {
    const colorMap = {
      blue: { bg: 'bg-blue-100', text: 'text-blue-600' },
      green: { bg: 'bg-green-100', text: 'text-green-600' },
      yellow: { bg: 'bg-yellow-100', text: 'text-yellow-600' },
      purple: { bg: 'bg-purple-100', text: 'text-purple-600' }
    };
    const c = colorMap[color] || colorMap.blue;
    return (
      <div className="bg-white p-6 rounded-lg shadow-sm border">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-gray-600">{title}</p>
            <p className="text-3xl font-bold text-gray-900">{value || 0}</p>
            {trend && (
              <p className="text-sm text-green-600 flex items-center mt-1">
                <TrendingUp className="h-4 w-4 mr-1" />
                {trend}
              </p>
            )}
          </div>
          <div className={`p-3 rounded-full ${c.bg}`}>
            <Icon className={`h-6 w-6 ${c.text}`} />
          </div>
        </div>
      </div>
    );
  };

  const StatusBadge = ({ status }) => {
    const statusConfig = {
      Pending: { bg: 'bg-yellow-100', text: 'text-yellow-800', label: 'Pending' },
      Approved: { bg: 'bg-green-100', text: 'text-green-800', label: 'Approved' },
      Rejected: { bg: 'bg-red-100', text: 'text-red-800', label: 'Rejected' },
      'Under Review': { bg: 'bg-blue-100', text: 'text-blue-800', label: 'Under Review' }
    };
    const config = statusConfig[status] || statusConfig['Pending'];
    
    return (
      <span className={`inline-flex px-2 py-1 text-xs font-medium rounded-full ${config.bg} ${config.text}`}>
        {status}
      </span>
    );
  };

  if (statsLoading || usersLoading || expensesLoading) {
    return (
      <div className="flex items-center justify-center min-h-96">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading admin dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 flex items-center">
            <Shield className="h-8 w-8 text-blue-600 mr-3" />
            Admin Dashboard
          </h1>
          <p className="text-gray-600 mt-1">Welcome back, {user?.name}! Manage your company.</p>
        </div>
        <div className="flex items-center space-x-4">
          <button 
            onClick={handleAddUser}
            className="btn btn-primary flex items-center"
          >
            <UserPlus className="h-4 w-4 mr-2" />
            Add User
          </button>
          <button 
            onClick={() => {/* Open settings modal */}}
            className="btn btn-outline flex items-center"
          >
            <Settings className="h-4 w-4 mr-2" />
            Settings
          </button>
        </div>
      </div>

      {/* Top Row: Company Info + Quick Actions Side by Side */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-gradient-to-r from-blue-500 to-blue-600 rounded-lg p-6 text-white">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Building2 className="h-12 w-12" />
              <div>
                <h2 className="text-2xl font-bold">{user?.companyId?.name || 'Your Company'}</h2>
                <p className="text-blue-100">Default Currency: {user?.companyId?.currency || 'USD'}</p>
              </div>
            </div>
            <div className="text-right">
              <p className="text-sm text-blue-200">Established</p>
              <p className="text-lg font-semibold">{new Date().getFullYear()}</p>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-lg shadow-sm border p-6 flex items-center justify-between">
          <div>
            <p className="text-sm text-gray-500">Quick actions</p>
            <p className="text-lg font-semibold text-gray-900">Invite or configure</p>
          </div>
          <div className="flex items-center space-x-3">
            <button onClick={handleAddUser} className="btn btn-primary btn-sm flex items-center">
              <UserPlus className="h-4 w-4 mr-1" /> Add
            </button>
            <button className="btn btn-outline btn-sm flex items-center">
              <Settings className="h-4 w-4 mr-1" /> Settings
            </button>
          </div>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard
          title="Total Users"
          value={usersData?.data?.length || 0}
          icon={Users}
          color="purple"
          trend={`${usersData?.data?.filter(u => u.role === 'Employee').length || 0} employees`}
        />
        <StatCard
          title="Total Expenses"
          value={stats?.total || 0}
          icon={BarChart3}
          color="blue"
        />
        <StatCard
          title="Pending Approvals"
          value={stats?.pending || 0}
          icon={Clock}
          color="yellow"
        />
        <StatCard
          title="Approved This Month"
          value={stats?.approved || 0}
          icon={CheckCircle}
          color="green"
        />
      </div>

      {/* Middle Row: Users and Recent Expenses Side by Side */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      <div className="bg-white rounded-lg shadow-sm border">
        <div className="px-6 py-4 border-b">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-semibold text-gray-900 flex items-center">
              <Users className="h-5 w-5 mr-3 text-blue-600" />
              Company Users ({usersData?.data?.length || 0})
            </h2>
            <button 
              onClick={handleAddUser}
              className="btn btn-primary btn-sm flex items-center"
            >
              <Plus className="h-4 w-4 mr-1" />
              Add User
            </button>
          </div>
        </div>
        
        <div className="divide-y">
          {usersData?.data?.length > 0 ? (
            usersData.data.map((userItem) => (
              <div key={userItem._id} className="px-6 py-4 flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <div className="flex-shrink-0">
                    <div className="h-10 w-10 bg-gray-600 rounded-full flex items-center justify-center">
                      <span className="text-white font-medium text-sm">
                        {userItem.name.charAt(0).toUpperCase()}
                      </span>
                    </div>
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="text-sm font-medium text-gray-900 truncate">
                      {userItem.name}
                    </p>
                    <p className="text-sm text-gray-500">
                      {userItem.email} • {userItem.role}
                    </p>
                    {userItem.department && (
                      <p className="text-xs text-gray-400">{userItem.department}</p>
                    )}
                  </div>
                </div>
                <div className="flex items-center space-x-4">
                  <div className="text-right">
                    <p className="text-sm font-medium text-gray-900">
                      {userItem.role}
                    </p>
                    <p className={`text-sm ${userItem.isActive ? 'text-green-600' : 'text-red-600'}`}>
                      {userItem.isActive ? 'Active' : 'Inactive'}
                    </p>
                  </div>
                  <div className="flex space-x-2">
                            <button
                              onClick={() => handleEditUser(userItem)}
                              className="btn btn-outline btn-sm"
                            >
                              Edit
                            </button>
                            {userItem.role !== 'Admin' && (
                              userItem.isActive ? (
                                <button 
                                  onClick={() => handleDeactivateUser(userItem._id, userItem.name)}
                                  className="btn btn-outline btn-sm text-red-600 hover:bg-red-50"
                                  disabled={deactivateUserMutation.isLoading}
                                >
                                  {deactivateUserMutation.isLoading ? 'Deactivating...' : 'Deactivate'}
                                </button>
                              ) : (
                                <button 
                                  onClick={() => handleReactivateUser(userItem._id, userItem.name)}
                                  className="btn btn-outline btn-sm text-green-600 hover:bg-green-50"
                                  disabled={reactivateUserMutation.isLoading}
                                >
                                  {reactivateUserMutation.isLoading ? 'Reactivating...' : 'Reactivate'}
                                </button>
                              )
                            )}
                  </div>
                </div>
              </div>
            ))
          ) : (
            <div className="px-6 py-12 text-center">
              <Users className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-500">No users found</p>
              <p className="text-sm text-gray-400 mt-1">Add your first employee or manager</p>
            </div>
          )}
        </div>
      </div>
      <div className="bg-white rounded-lg shadow-sm border">
        <div className="px-6 py-4 border-b">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-semibold text-gray-900">Recent Company Expenses</h2>
            <button className="text-blue-600 hover:text-blue-700 text-sm font-medium">
              View all expenses
            </button>
          </div>
        </div>
        
        <div className="divide-y">
          {expensesData?.data?.length > 0 ? (
            expensesData.data.map((expense) => (
              <div key={expense._id} className="px-6 py-4 flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <div className="flex-shrink-0">
                    <BarChart3 className="h-8 w-8 text-gray-400" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="text-sm font-medium text-gray-900 truncate">
                      {expense.description}
                    </p>
                    <p className="text-sm text-gray-500">
                      {expense.employeeId.name} • {expense.category} • {new Date(expense.date).toLocaleDateString()}
                    </p>
                  </div>
                </div>
                <div className="flex items-center space-x-4">
                  <div className="text-right">
                    <p className="text-sm font-medium text-gray-900">
                      {expense.currency} {expense.amount}
                    </p>
                    <p className="text-sm text-gray-500">
                      ≈ {expense.companyId.currency} {expense.convertedAmount}
                    </p>
                  </div>
                  <StatusBadge status={expense.status} />
                </div>
              </div>
            ))
          ) : (
            <div className="px-6 py-12 text-center">
              <BarChart3 className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-500">No expenses yet</p>
              <p className="text-sm text-gray-400 mt-1">Employees will submit expenses here</p>
            </div>
          )}
        </div>
      </div>
      </div>

      {/* Bottom Row: Quick Actions */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white rounded-lg shadow-sm border p-6">
          <div className="flex items-center mb-4">
            <Users className="h-8 w-8 text-purple-600 mr-3" />
            <h3 className="text-lg font-semibold text-gray-900">User Management</h3>
          </div>
          <p className="text-gray-600 mb-4">Create and manage employees, managers, and organizational structure.</p>
          <button 
            onClick={handleAddUser}
            className="btn btn-primary w-full"
          >
            Manage Users
          </button>
        </div>

        <div className="bg-white rounded-lg shadow-sm border p-6">
          <div className="flex items-center mb-4">
            <Settings className="h-8 w-8 text-blue-600 mr-3" />
            <h3 className="text-lg font-semibold text-gray-900">Approval Rules</h3>
          </div>
          <p className="text-gray-600 mb-4">Configure multi-level approval workflows and conditional rules.</p>
          <button 
            onClick={() => window.location.href = '/rules'}
            className="btn btn-primary w-full"
          >
            Configure Rules
          </button>
        </div>

        <div className="bg-white rounded-lg shadow-sm border p-6">
          <div className="flex items-center mb-4">
            <BarChart3 className="h-8 w-8 text-green-600 mr-3" />
            <h3 className="text-lg font-semibold text-gray-900">Analytics & Reports</h3>
          </div>
          <p className="text-gray-600 mb-4">Generate expense reports and analyze company spending patterns.</p>
          <button 
            onClick={() => window.location.href = '/reports'}
            className="btn btn-primary w-full"
          >
            View Reports
          </button>
        </div>
      </div>

      {/* User Management Modal */}
      <UserManagementModal
        isOpen={showUserModal}
        onClose={handleCloseModal}
        editUser={editingUser}
      />
    </div>
  );
};

export default AdminDashboard;
