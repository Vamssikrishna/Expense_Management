import React, { useState } from 'react';
import { useQuery } from 'react-query';
import axios from 'axios';
import { useAuth } from '../context/AuthContext';
import {
  Search,
  Filter,
  Download,
  Receipt,
  Calendar,
  MapPin,
  FileText,
  Eye,
  Edit,
  Trash2,
  Plus,
  Clock,
  CheckCircle,
  XCircle,
  DollarSign
} from 'lucide-react';
import toast from 'react-hot-toast';

const ExpenseHistory = () => {
  const { user } = useAuth();
  const [filters, setFilters] = useState({
    status: '',
    category: '',
    dateFrom: '',
    dateTo: '',
    search: ''
  });

  // Fetch user expenses with filters
  const { data: expensesData, isLoading } = useQuery(
    ['expenses-history', filters],
    () => {
      const params = new URLSearchParams();
      if (filters.status) params.append('status', filters.status);
      if (filters.category) params.append('category', filters.category);
      if (filters.dateFrom) params.append('dateFrom', filters.dateFrom);
      if (filters.dateTo) params.append('dateTo', filters.dateTo);
      if (filters.search) params.append('search', filters.search);
      
      return axios.get(`/api/expenses/my-expenses?${params.toString()}`)
        .then(res => res.data.data);
    },
    {
      enabled: !!user
    }
  );

  const handleFilterChange = (key, value) => {
    setFilters(prev => ({ ...prev, [key]: value }));
  };

  const resetFilters = () => {
    setFilters({
      status: '',
      category: '',
      dateFrom: '',
      dateTo: '',
      search: ''
    });
  };

  const exportExpenses = () => {
    toast.success('Export feature coming soon!');
  };

  const StatusBadge = ({ status, approvals }) => {
    const statusConfig = {
      Pending: { bg: 'bg-yellow-100', text: 'text-yellow-800', icon: Clock },
      Approved: { bg: 'bg-green-100', text: 'text-green-800', icon: CheckCircle },
      Rejected: { bg: 'bg-red-100', text: 'text-red-800', icon: XCircle },
      'Under Review': { bg: 'bg-blue-100', text: 'text-blue-800', icon: Eye }
    };

    const config = statusConfig[status] || statusConfig['Pending'];
    const Icon = config.icon;

    return (
      <div className="flex flex-col items-end space-y-2">
        <span className={`inline-flex items-center px-3 py-1 text-sm font-medium rounded-full ${config.bg} ${config.text}`}>
          <Icon className="h-4 w-4 mr-1" />
          {status}
        </span>
        
        {/* Approval Timeline */}
        {approvals && approvals.length > 0 && (
          <div className="text-xs text-gray-500 mt-1">
            {approvals.slice(0, 2).map((approval, index) => (
              <div key={approval._id} className="flex items-center mb-1">
                <div className={`w-2 h-2 rounded-full mr-1 ${
                  approval.status === 'Approved' ? ' andgreen-500' : 
                  approval.status === 'Rejected' ? 'bg-red-500' : 'bg-gray-300'
                }`} />
                <span>{approval.approver.name}</span>
              </div>
            ))}
            {approvals.length > 2 && (
              <div className="text-gray-400">+{approvals.length - 2} more</div>
            )}
          </div>
        )}
      </div>
    );
  };

  const categories = [
    'Travel', 'Food', 'Lodging', 'Office Supplies', 'Transportation',
    'Meals', 'Telephone', 'Internet', 'Software', 'Training'
  ];

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-96">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading expense history...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Expense History</h1>
          <p className="text-gray-600 mt-1">Track and manage your submitted expenses</p>
        </div>
        <div className="flex items-center space-x-4">
          <button
            onClick={exportExpenses}
            className="btn btn-outline flex items-center"
          >
            <Download className="h-4 w-4 mr-2" />
            Export
          </button>
          <button
            onClick={() => window.location.href = '/submit-expense'}
            className="btn btn-primary flex items-center"
          >
            <Plus className="h-4 w-4 mr-2" />
            New Expense
          </button>
        </div>
      </div>

      {/* Summary Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-white p-6 rounded-lg shadow-sm border">
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <Receipt className="h-8 w-8 text-blue-600" />
            </div>
            <div className="ml-5 w-0 flex-1">
              <div>
                <p className="text-sm font-medium text-gray-500">Total Expenses</p>
                <p className="text-lg font-medium text-gray-900">{expensesData?.data?.length || 0}</p>
              </div>
            </div>
          </div>
        </div>
        
        <div className="bg-white p-6 rounded-lg shadow-sm border">
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <Clock className="h-8 w-8 text-yellow-600" />
            </div>
            <div className="ml-5 w-0 flex-1">
              <div>
                <p className="text-sm font-medium text-gray-500">Pending</p>
                <p className="text-lg font-medium text-gray-900">
                  {expensesData?.data?.filter(e => e.status === 'Pending').length || 0}
                </p>
              </div>
            </div>
          </div>
        </div>
        
        <div className="bg-white p-6 rounded-lg shadow-sm border">
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <CheckCircle className="h-8 w-8 text-green-600" />
            </div>
            <div className="ml-5 w-0 flex-1">
              <div>
                <p className="text-sm font-medium text-gray-500">Approved</p>
                <p className="text-lg font-medium text-gray-900">
                  {expensesData?.data?.filter(e => e.status === 'Approved').length || 0}
                </p>
              </div>
            </div>
          </div>
        </div>
        
        <div className="bg-white p-6 rounded-lg shadow-sm border">
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <DollarSign className="h-8 w-8 text-green-600" />
            </div>
            <div className="ml-5 w-0 flex-1">
              <div>
                <p className="text-sm font-medium text-gray-500">Total Amount</p>
                <p className="text-lg font-medium text-gray-900">
                  {user?.companyId?.currency} ${expensesData?.reduce((sum, e) => sum + (e.convertedAmount || 0), 0) || 0}
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-lg shadow-sm border p-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-medium text-gray-900 flex items-center">
            <Filter className="h-5 w-5 mr-2" />
            Filter Expenses
          </h2>
          <button
            onClick={resetFilters}
            className="text-sm text-gray-500 hover:text-gray-700"
          >
            Clear Filters
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          {/* Search */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Search
            </label>
            <div className="relative">
              <Search className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
              <input
                type="text"
                value={filters.search}
                onChange={(e) => handleFilterChange('search', e.target.value)}
                placeholder="Description, merchant..."
                className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md focus:ring-1 focus:ring-blue-500 focus:border-blue-500"
              />
            </div>
          </div>

          {/* Status */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Status
            </label>
            <select
              value={filters.status}
              onChange={(e) => handleFilterChange('status', e.target.value)}
              className="block w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-1 focus:ring-blue-500 focus:border-blue-500"
            >
              <option value="">All Statuses</option>
              <option value="Pending">Pending</option>
              <option value="Approved">Approved</option>
              <option value="Rejected">Rejected</option>
              <option value="Under Review">Under Review</option>
            </select>
          </div>

          {/* Category */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Category
            </label>
            <select
              value={filters.category}
              onChange={(e) => handleFilterChange('category', e.target.value)}
              className="block w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-1 focus:ring-blue-500 focus:border-blue-500"
            >
              <option value="">All Categories</option>
              {categories.map(cat => (
                <option key={cat} value={cat}>{cat}</option>
              ))}
            </select>
          </div>

          {/* Date From */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Date From
            </label>
            <div className="relative">
              <Calendar className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
              <input
                type="date"
                value={filters.dateFrom}
                onChange={(e) => handleFilterChange('dateFrom', e.target.value)}
                className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md focus:ring-1 focus:ring-blue-500 focus:border-blue-500"
              />
            </div>
          </div>
        </div>
      </div>

      {/* Expenses Table */}
      <div className="bg-white rounded-lg shadow-sm border">
        <div className="px-6 py-4 border-b">
          <h2 className="text-lg font-semibold text-gray-900">
            Your Expenses ({expensesData?.data?.length || 0})
          </h2>
        </div>
        
        {expensesData?.data?.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Expense Details
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Amount
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Status
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {expensesData?.data?.map((expense) => (
                  <tr key={expense._id} className="hover:bg-gray-50">
                    <td className="px-6 py-4">
                      <div className="space-y-2">
                        <div className="flex items-start space-x-3">
                          <Receipt className="h-6 w-6 text-blue-600 flex-shrink-0 mt-1" />
                          <div className="min-w-0 flex-1">
                            <h4 className="text-sm font-medium text-gray-900 truncate">
                              {expense.description}
                            </h4>
                            <div className="flex items-center space-x-4 text-sm text-gray-500 mt-1">
                              <span className="flex items-center">
                                <MapPin className="h-4 w-4 mr-1" />
                                {expense.category}
                              </span>
                              <span className="flex items-center">
                                <Calendar className="h-4 w-4 mr-1" />
                                {new Date(expense.date).toLocaleDateString()}
                              </span>
                            </div>
                            {expense.merchant && (
                              <p className="text-sm text-gray-500 mt-1">
                                Merchant: {expense.merchant}
                              </p>
                            )}
                          </div>
                        </div>
                        
                        {expense.tags && (
                          <div className="flex flex-wrap gap-1 ml-9">
                            {expense.tags.split(',').map((tag, index) => (
                              <span key={index} className="inline-flex px-2 py-1 text-xs font-medium bg-gray-100 text-gray-800 rounded-md">
                                {tag.trim()}
                              </span>
                            ))}
                          </div>
                        )}
                      </div>
                    </td>
                    
                    <td className="px-6 py-4">
                      <div className="text-right">
                        <div className="text-sm font-medium text-gray-900">
                          {expense.currency} {expense.amount}
                        </div>
                        <div className="text-sm text-gray-500">
                          ≈ {expense.companyId?.currency} {expense.convertedAmount}
                        </div>
                        {expense.receiptUrl && (
                          <button className="text-xs text-blue-600 hover:text-blue-800 mt-1 flex items-center ml-auto">
                            <FileText className="h-3 w-3 mr-1" />
                            View Receipt
                          </button>
                        )}
                      </div>
                    </td>
                    
                    <td className="px-6 py-4">
                      <StatusBadge 
                        status={expense.status} 
                        approvals={expense.approvals}
                      />
                    </td>
                    
                    <td className="px-6 py-4">
                      <div className="flex items-center space-x-2">
                        <button className="text-gray-400 hover:text-gray-600">
                          <Eye className="h-4 w-4" />
                        </button>
                        {expense.status === 'Pending' && (
                          <button className="text-gray-400 hover:text-gray-600">
                            <Edit className="h-4 w-4" />
                          </button>
                        )}
                        <button className="text-gray-400 hover:text-red-600">
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="px-6 py-12 text-center">
            <Receipt className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-500">No expenses found</p>
            <p className="text-sm text-gray-400 mt-1">
              {filters.search || filters.status || filters.category || filters.dateFrom
                ? 'Try adjusting your filters or '
                : 'Start by '}
              <button 
                onClick={() => window.location.href = '/submit-expense'}
                className="text-blue-600 hover:text-blue-700 font-medium"
              >
                submitting your first expense
              </button>
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default ExpenseHistory;
