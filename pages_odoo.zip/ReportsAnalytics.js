import React, { useState } from 'react';
import { useQuery } from 'react-query';
import axios from 'axios';
import { useAuth } from '../context/AuthContext';
import {
  BarChart3,
  TrendingUp,
  TrendingDown,
  DollarSign,
  Users,
  Download,
  Filter,
  PieChart,
  Activity,
  Target,
  AlertTriangle
} from 'lucide-react';
import { Bar, BarChart, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart as RechartsPieChart, Pie, Cell } from 'recharts';

const ReportsAnalytics = () => {
  const { user } = useAuth();
  const [timeRange, setTimeRange] = useState('30'); // days

  // Fetch analytics data
  const { data: analyticsData, isLoading } = useQuery(
    ['analytics', timeRange],
    () => {
      const params = new URLSearchParams({
        timeRange,
        userId: user?.role === 'Admin' ? 'all' : user?._id
      });
      return axios.get(`/api/analytics/reports?${params.toString()}`)
        .then(res => res.data.data);
    },
    {
      enabled: !!user
    }
  );

  // Mock data for demonstration
  const mockData = {
    overview: {
      totalExpenses: 45670,
      totalApproved: 42300,
      totalPending: 2370,
      totalRejected: 1000,
      avgProcessingTime: 2.3,
      approvalRate: 94.2,
      topCategories: [
        { name: 'Travel', amount: 18500, count: 45 },
        { name: 'Food', amount: 12300, count: 78 },
        { name: 'Office Supplies', amount: 8900, count: 23 },
        { name: 'Software', amount: 4200, count: 12 },
        { name: 'Training', amount: 1770, count: 8 }
      ],
      monthlyTrend: [
        { month: 'Jan', approved: 12000, pending: 2000, rejected: 500 },
        { month: 'Feb', approved: 14500, pending: 1500, rejected: 300 },
        { month: 'Mar', approved: 15800, pending: 1200, rejected: 200 }
      ],
      departmentBreakdown: [
        { name: 'Engineering', amount: 18500, percentage: 40.5 },
        { name: 'Sales', amount: 12300, percentage: 26.9 },
        { name: 'Marketing', amount: 8900, percentage: 19.5 },
        { name: 'HR', amount: 4200, percentage: 9.2 },
        { name: 'Finance', amount: 1770, percentage: 3.9 }
      ]
    },
    employee: {
      personalStats: {
        totalSubmitted: 12,
        totalApproved: 10,
        totalPending: 2,
        avgAmount: 145.50,
        monthlyLimit: 2000,
        remainingLimit: 1255.00
      },
      categoryBreakdown: [
        { name: 'Travel', amount: 850, percentage: 58.4 },
        { name: 'Food', amount: 320, percentage: 22.0 },
        { name: 'Office Supplies', amount: 285.50, percentage: 19.6 }
      ]
    }
  };

  const data = analyticsData || mockData[user?.role === 'Employee' ? 'employee' : 'overview'];

  const COLORS = ['#3B82F6', '#10B981', '#F59E0B', '#EF4444', '#8B5CF6'];

  const StatCard = ({ title, value, icon: Icon, color = 'blue', trend, subtitle }) => (
    <div className="bg-white p-6 rounded-lg shadow-sm border">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm font-medium text-gray-600">{title}</p>
          <p className="text-3xl font-bold text-gray-900">{value}</p>
          {trend && (
            <p className={`text-sm flex items-center mt-1 ${
              trend.includes('+') ? 'text-green-600' : 'text-red-600'
            }`}>
              {trend.includes('+') ? <TrendingUp className="h-4 w-4 mr-1" /> : <TrendingDown className="h-4 w-4 mr-1" />}
              {trend}
            </p>
          )}
          {subtitle && (
            <p className="text-sm text-gray-500 mt-1">{subtitle}</p>
          )}
        </div>
        <div className={`p-3 rounded-full bg-${color}-100`}>
          <Icon className={`h-6 w-6 text-${color}-600`} />
        </div>
      </div>
    </div>
  );

  const generateReport = () => {
    // This would generate a PDF/Excel report
    console.log('Generating report...');
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-96">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading analytics...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 flex items-center">
            <BarChart3 className="h-8 w-8 text-blue-600 mr-3" />
            Reports & Analytics
          </h1>
          <p className="text-gray-600 mt-1">
            {user?.role === 'Employee' ? 'Your personal expense analytics' : 'Company-wide expense insights and trends'}
          </p>
        </div>
        <div className="flex items-center space-x-4">
          <select
            value={timeRange}
            onChange={(e) => setTimeRange(e.target.value)}
            className="border border-gray-300 rounded-md px-3 py-2 focus:ring-1 focus:ring-blue-500 focus:border-blue-500"
          >
            <option value="7">Last 7 days</option>
            <option value="30">Last 30 days</option>
            <option value="90">Last 90 days</option>
            <option value="365">Last year</option>
          </select>
          <button
            onClick={generateReport}
            className="btn btn-primary flex items-center"
          >
            <Download className="h-4 w-4 mr-2" />
            Export Report
          </button>
        </div>
      </div>

      {/* Key Metrics */}
      {user?.role !== 'Employee' ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <StatCard
            title="Total Expenses"
            value={`${user?.companyId?.currency} $${data.totalExpenses?.toLocaleString()}`}
            icon={DollarSign}
            color="blue"
            trend="+12.5%"
          />
          <StatCard
            title="Approval Rate"
            value={`${data.approvalRate}%`}
            icon={Target}
            color="green"
            trend="+2.1%"
          />
          <StatCard
            title="Avg Processing"
            value={`${data.avgProcessingTime} days`}
            icon={Activity}
            color="purple"
            trend="-0.3 days"
          />
          <StatCard
            title="Pending Review"
            value={`${user?.companyId?.currency} $${data.totalPending?.toLocaleString()}`}
            icon={AlertTriangle}
            color="yellow"
          />
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <StatCard
            title="Monthly Limit"
            value={`${user?.companyId?.currency} $${data.personalStats?.monthlyLimit}`}
            icon={Target}
            color="blue"
            subtitle={`${user?.companyId?.currency} $${data.personalStats?.remainingLimit} remaining`}
          />
          <StatCard
            title="Submitted"
            value={data.personalStats?.totalSubmitted}
            icon={BarChart3}
            color="purple"
          />
          <StatCard
            title="Approved"
            value={data.personalStats?.totalApproved}
            icon={Target}
            color="green"
            trend="83%"
          />
          <StatCard
            title="Avg Amount"
            value={`${user?.companyId?.currency} $${data.personalStats?.avgAmount}`}
            icon={DollarSign}
            color="yellow"
          />
        </div>
      )}

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Monthly Trend Chart */}
        <div className="bg-white rounded-lg shadow-sm border p-6">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-semibold text-gray-900">Monthly Trends</h3>
            <Filter className="h-5 w-5 text-gray-400" />
          </div>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={data.monthlyTrend}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="month" />
              <YAxis />
              <Tooltip formatter={(value) => [`$${value}`, '']} />
              <Bar dataKey="approved" fill="#10B981" name="Approved" />
              <Bar dataKey="pending" fill="#F59E0B" name="Pending" />
              <Bar dataKey="rejected" fill="#EF4444" name="Rejected" />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Category Breakdown */}
        <div className="bg-white rounded-lg shadow-sm border p-6">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-semibold text-gray-900">Category Breakdown</h3>
            <PieChart className="h-5 w-5 text-gray-400" />
          </div>
          <ResponsiveContainer width="100%" height={300}>
            <RechartsPieChart>
              <Pie
                data={user?.role === 'Employee' ? data.categoryBreakdown : data.topCategories}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={({ name, percentage }) => `${name} ${percentage}%`}
                outerRadius={80}
                fill="#8884d8"
                dataKey="amount"
              >
                {(user?.role === 'Employee' ? data.categoryBreakdown : data.topCategories)?.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip formatter={(value) => [`$${value}`, 'Amount']} />
            </RechartsPieChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Department/Team Breakdown (Admin/Manager only) */}
      {user?.role !== 'Employee' && (
        <div className="bg-white rounded-lg shadow-sm border p-6">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-semibold text-gray-900">Department Breakdown</h3>
            <Users className="h-5 w-5 text-gray-400" />
          </div>
          <div className="space-y-4">
            {data.departmentBreakdown?.map((dept, index) => (
              <div key={dept.name} className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <div className="w-4 h-4 rounded-full" style={{ backgroundColor: COLORS[index % COLORS.length] }}></div>
                  <span className="text-sm font-medium text-gray-900">{dept.name}</span>
                </div>
                <div className="flex items-center space-x-4">
                  <div className="w-32 bg-gray-200 rounded-full h-2">
                    <div
                      className="h-2 rounded-full"
                      style={{
                        width: `${dept.percentage}%`,
                        backgroundColor: COLORS[index % COLORS.length]
                      }}
                    ></div>
                  </div>
                  <span className="text-sm text-gray-600 w-20 text-right">
                    {user?.companyId?.currency} ${dept.amount.toLocaleString()}
                  </span>
                  <span className="text-sm text-gray-500 w-12 text-right">
                    {dept.percentage}%
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Top Categories Table */}
      <div className="bg-white rounded-lg shadow-sm border">
        <div className="px-6 py-4 border-b">
          <h3 className="text-lg font-semibold text-gray-900">Top Expense Categories</h3>
        </div>
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Category
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Amount
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Count
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Avg per Item
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Trend
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {(user?.role === 'Employee' ? data.categoryBreakdown : data.topCategories)?.map((category, index) => (
                <tr key={category.name} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <div className="w-3 h-3 rounded-full mr-3" style={{ backgroundColor: COLORS[index % COLORS.length] }}></div>
                      <span className="text-sm font-medium text-gray-900">{category.name}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {user?.companyId?.currency} ${category.amount?.toLocaleString()}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {category.count || Math.round(category.amount / 100)}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {user?.companyId?.currency} ${Math.round(category.amount / (category.count || 1))}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center text-green-600">
                      <TrendingUp className="h-4 w-4 mr-1" />
                      <span className="text-sm">+{Math.round(Math.random() * 20 + 5)}%</span>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default ReportsAnalytics;
