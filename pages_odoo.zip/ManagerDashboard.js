import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from 'react-query';
import axios from 'axios';
import { useAuth } from '../context/AuthContext';
import {
  CheckCircle,
  Clock,
  BarChart3,
  FileText,
  AlertCircle,
  TrendingUp,
  Users,
  User,
  Calendar,
  X
} from 'lucide-react';
import toast from 'react-hot-toast';

const ManagerDashboard = () => {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const [selectedExpense, setSelectedExpense] = useState(null);
  const [showApprovalModal, setShowApprovalModal] = useState(false);

  // Fetch pending approvals for this manager
  const { data: pendingApprovals, isLoading: pendingLoading } = useQuery(
    'pending-approvals',
    () => axios.get('/api/expenses/approvals/pending').then(res => res.data.data),
    {
      enabled: !!user && user.role === 'Manager'
    }
  );

  // Fetch manager stats (via approval stats endpoint)
  const { data: managerStats, isLoading: statsLoading } = useQuery(
    'manager-stats',
    () => axios.get('/api/approvals/stats').then(res => res.data.data),
    {
      enabled: !!user && user.role === 'Manager'
    }
  );

  // Fetch team structure (direct reports)
  const { data: teamStructure, isLoading: teamLoading } = useQuery(
    'team-structure',
    () => axios.get('/api/users/directReports').then(res => res.data.data),
    {
      enabled: !!user && user.role === 'Manager'
    }
  );

  // Approve expense mutation
  const approveExpenseMutation = useMutation(
    ({ expenseId, comment }) => 
      axios.post(`/api/approvals/approve/${expenseId}`, { comments: comment }),
    {
      onSuccess: () => {
        queryClient.invalidateQueries('pending-approvals');
        queryClient.invalidateQueries('manager-stats');
        toast.success('Expense approved successfully!');
        setShowApprovalModal(false);
        setSelectedExpense(null);
      },
      onError: (error) => {
        toast.error(error.response?.data?.message || 'Failed to approve expense');
      }
    }
  );

  // Reject expense mutation
  const rejectExpenseMutation = useMutation(
    ({ expenseId, reason }) => 
      axios.post(`/api/approvals/reject/${expenseId}`, { reason }),
    {
      onSuccess: () => {
        queryClient.invalidateQueries('pending-approvals');
        queryClient.invalidateQueries('manager-stats');
        toast.success('Expense rejected successfully!');
        setShowApprovalModal(false);
        setSelectedExpense(null);
      },
      onError: (error) => {
        toast.error(error.response?.data?.message || 'Failed to reject expense');
      }
    }
  );

  const handleApprovalAction = (action, expenseId, commentOrReason) => {
    if (action === 'approve') {
      approveExpenseMutation.mutate({ expenseId, comment: commentOrReason });
    } else {
      rejectExpenseMutation.mutate({ expenseId, reason: commentOrReason });
    }
  };

  const StatCard = ({ title, value, icon: Icon, color = 'blue', subtitle }) => (
    <div className="bg-white p-6 rounded-lg shadow-sm border">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm font-medium text-gray-600">{title}</p>
          <p className="text-3xl font-bold text-gray-900">{value || 0}</p>
          {subtitle && (
            <p className="text-sm text-gray-500 mt-1">{subtitle}</p>
          )}
        </div>
        <div className={`p-3 rounded-full bg-${color}-100`}>
          <Icon className={`h-6 w-6 text-${color}-600`} />
        </div>
      </div>
    </div>
  );

  const CurrencyBadge = ({ amount, currency }) => (
    <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
      {currency} {amount}
    </span>
  );

  const PriorityBadge = ({ priority }) => {
    const config = {
      High: 'bg-red-100 text-red-800',
      Medium: 'bg-yellow-100 text-yellow-800',
      Low: 'bg-green-100 text-green-800'
    };
    
    return (
      <span className={`inline-flex px-2 py-1 text-xs font-medium rounded-full ${config[priority] || config.Low}`}>
        {priority || 'Low'}
      </span>
    );
  };

  if (pendingLoading || statsLoading || teamLoading) {
    return (
      <div className="flex items-center justify-center min-h-96">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading manager dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 flex items-center">
            <Users className="h-8 w-8 text-blue-600 mr-3" />
            Manager Dashboard
          </h1>
          <p className="text-gray-600 mt-1">Welcome back, {user?.name}! Review and approve team expenses.</p>
        </div>
        <div className="text-right">
          <p className="text-sm text-gray-500">Team Leader</p>
          <p className="text-lg font-semibold text-gray-900">{user?.department || 'General Management'}</p>
        </div>
      </div>

      {/* Manager Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard
          title="Pending Approvals"
          value={pendingApprovals?.length || 0}
          icon={Clock}
          color="yellow"
          subtitle="Awaiting your review"
        />
        <StatCard
          title="Approved This Month"
          value={managerStats?.approvedCount || 0}
          icon={CheckCircle}
          color="green"
          subtitle={`${user?.companyId?.currency} $(managerStats?.approvedAmount || 0)`}
        />
        <StatCard
          title="Team Members"
          value={teamStructure?.directReports?.length || 0}
          icon={User}
          color="purple"
          subtitle="Direct reports"
        />
        <StatCard
          title="Team Expenses"
          value={managerStats?.totalExpenses || 0}
          icon={BarChart3}
          color="blue"
          subtitle="This month"
        />
      </div>

      {/* Team Overview */}
      {teamStructure?.directReports && teamStructure.directReports.length > 0 && (
        <div className="bg-white rounded-lg shadow-sm border">
          <div className="px-6 py-4 border-b">
            <h2 className="text-lg font-semibold text-gray-900">Team Overview</h2>
          </div>
          <div className="divide-y">
            {teamStructure.directReports.map((member) => (
              <div key={member._id} className="px-6 py-4 flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <div className="h-10 w-10 bg-gray-600 rounded-full flex items-center justify-center">
                    <span className="text-white font-medium text-sm">
                      {member.name.charAt(0).toUpperCase()}
                    </span>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-900">{member.name}</p>
                    <p className="text-sm text-gray-500">{member.jobTitle || member.department}</p>
                  </div>
                </div>
                <div className="flex items-center space-x-4">
                  <div className="text-right text-sm">
                    <p className="text-gray-900">{member.totalExpenses || 0} expenses</p>
                    <p className="text-gray-500">{user?.companyId?.currency} $(member.totalAmount || 0)</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Pending Approvals */}
      <div className="bg-white rounded-lg shadow-sm border">
        <div className="px-6 py-4 border-b">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-semibold text-gray-900 flex items-center">
              <Clock className="h-5 w-5 mr-3 text-yellow-600" />
              Pending Approvals ({pendingApprovals?.length || 0})
            </h2>
            <button className="text-blue-600 hover:text-blue-700 text-sm font-medium">
              View all requests
            </button>
          </div>
        </div>
        
        <div className="divide-y">
          {pendingApprovals?.length > 0 ? (
            pendingApprovals.map((expense) => (
              <div key={expense._id} className="px-6 py-4">
                <div className="flex items-start justify-between">
                  <div className>

                    {/* Employee Info */}
                    <div className="flex items-center space-x-4 mb-4">
                      <div className="h-8 w-8 bg-gray-600 rounded-full flex items-center justify-center">
                        <span className="text-white font-medium text-xs">
                          {expense.employeeId.name.charAt(0).toUpperCase()}
                        </span>
                      </div>
                      <div>
                        <p className="text-sm font-medium text-gray-900">{expense.employeeId.name}</p>
                        <p className="text-sm text-gray-500">{expense.employeeId.department}</p>
                      </div>
                      <PriorityBadge priority="Medium" />
                    </div>

                    {/* Expense Details */}
                    <div className="space-y-3">
                      <div className="flex items-center space-x-6 text-sm">
                        <div className="flex items-center">
                          <BarChart3 className="h-4 w-4 text-gray-400 mr-2" />
                          <span className="text-gray-600">Category:</span>
                          <span className="ml-2 font-medium">{expense.category}</span>
                        </div>
                        <div className="flex items-center">
                          <Calendar className="h-4 w-4 text-gray-400 mr-2" />
                          <span className="text-gray-600">Date:</span>
                          <span className="ml-2 font-medium">{new Date(expense.date).toLocaleDateString()}</span>
                        </div>
                      </div>

                      <div className="space-y-2">
                        <div className="flex items-center space-x-6 text-sm">
                          <div className="flex items-center">
                            <CurrencyBadge amount={expense.amount} currency={expense.currency} />
                            <span className="ml-2 text-gray-600">
                              ≈ {user?.companyId?.currency} ${expense.convertedAmount}
                            </span>
                          </div>
                        </div>
                        {expense.receiptUrl && (
                          <div className="flex items-center">
                            <FileText className="h-4 w-4 text-gray-400 mr-2" />
                            <button className="text-blue-600 hover:text-blue-700 text-sm">
                              View Receipt
                            </button>
                          </div>
                        )}
                      </div>

                      <div className="bg-gray-50 border border-gray-200 rounded-lg p-3">
                        <p className="text-sm font-medium text-gray-900 mb-1">Description:</p>
                        <p className="text-sm text-gray-700">{expense.description}</p>
                      </div>

                      {/* Approval Actions */}
                      <div className="flex items-center space-x-4 pt-4">
                        <button
                          onClick={() => {
                            setSelectedExpense(expense);
                            setShowApprovalModal(true);
                          }}
                          className="btn btn-primary btn-sm flex items-center"
                        >
                          <CheckCircle className="h-4 w-4 mr-1" />
                          Review & Approve
                        </button>
                        <button className="btn btn-outline btn-sm text-gray-600">
                          <AlertCircle className="h-4 w-4 mr-1" />
                          Request More Info
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ))
          ) : (
          <div className="px-6 py-12 text-center">
              <Clock className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-500">No pending approvals</p>
              <p className="text-sm text-gray-400 mt-1">All expense requests have been reviewed</p>
            </div>
          )}
        </div>
      </div>

      {/* Approval History */}
      <div className="bg-white rounded-lg shadow-sm border">
        <div className="px-6 py-4 border-b">
          <h2 className="text-lg font-semibold text-gray-900">Recent Approvals</h2>
        </div>
        <div className="px-6 py-12 text-center">
          <TrendingUp className="h-12 w-12 text-gray-400 mx-auto mb-4" />
          <p className="text-gray-500">Approval history coming soon</p>
          <p className="text-sm text-gray-400 mt-1">Track your team's expense patterns</p>
        </div>
      </div>

      {/* Approval Modal */}
      {showApprovalModal && selectedExpense && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg shadow-xl w-full max-w-md p-6">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-xl font-semibold text-gray-900">Review Expense</h3>
              <button 
                onClick={() => {
                  setShowApprovalModal(false);
                  setSelectedExpense(null);
                }} 
                className="text-gray-400 hover:text-gray-600"
              >
                <X className="h-6 w-6" />
              </button>
            </div>
            <div className="space-y-4">
              <div>
                <p className="text-sm text-gray-500">Employee</p>
                <p className="font-medium text-gray-900">{selectedExpense.employeeId?.name}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Description</p>
                <p className="font-medium text-gray-900">{selectedExpense.description}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Amount</p>
                <p className="font-medium text-gray-900">{selectedExpense.currency} {selectedExpense.amount}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Category</p>
                <p className="font-medium text-gray-900">{selectedExpense.category}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Date</p>
                <p className="font-medium text-gray-900">{new Date(selectedExpense.date).toLocaleDateString()}</p>
              </div>
              <div className="mt-4">
                <label htmlFor="comment" className="block text-sm font-medium text-gray-700">
                  Comment/Reason
                </label>
                <textarea
                  id="comment"
                  rows="3"
                  className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2 focus:ring-blue-500 focus:border-blue-500"
                  placeholder="Add a comment for approval or rejection reason"
                ></textarea>
              </div>
              <div className="flex justify-end space-x-3 mt-6">
                <button
                  onClick={() => handleApprovalAction('reject', selectedExpense._id, document.getElementById('comment').value)}
                  className="btn btn-outline text-red-600 hover:bg-red-50"
                  disabled={rejectExpenseMutation.isLoading}
                >
                  {rejectExpenseMutation.isLoading ? 'Rejecting...' : 'Reject'}
                </button>
                <button
                  onClick={() => handleApprovalAction('approve', selectedExpense._id, document.getElementById('comment').value)}
                  className="btn btn-primary"
                  disabled={approveExpenseMutation.isLoading}
                >
                  {approveExpenseMutation.isLoading ? 'Approving...' : 'Approve'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ManagerDashboard;
