import React from 'react';

const RulesConfig = () => (
  <div className="max-w-7xl mx-auto">
    <h1 className="text-3xl font-bold text-gray-900 mb-8">Approval Rules Configuration</h1>
    <div className="bg-white rounded-lg shadow-sm border p-8">
      <p className="text-gray-600">Admin interface for creating and managing approval rules.</p>
      <p className="text-sm text-gray-500 mt-2">
        Features: Rule builder, condition editor, rule testing, priority management
      </p>
    </div>
  </div>
);

export default RulesConfig;



