import React, { useState, useRef } from 'react';
import { useForm } from 'react-hook-form';
import { useMutation, useQueryClient } from 'react-query';
import axios from 'axios';
import { useAuth } from '../context/AuthContext';
import {
  Upload,
  FileText,
  DollarSign,
  Calendar,
  MapPin,
  Building2,
  Zap,
  CheckCircle,
  AlertCircle
} from 'lucide-react';
import toast from 'react-hot-toast';

const ExpenseSubmissionForm = () => {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const fileInputRef = useRef(null);
  const [receiptUpload, setReceiptUpload] = useState(null); // { url, name }
  const [isProcessingOCR, setIsProcessingOCR] = useState(false);
  const [ocrResults, setOcrResults] = useState(null);

  const {
    register,
    handleSubmit,
    formState: { errors },
    setValue,
    watch,
    reset
  } = useForm();

  const watchedValues = watch();

  // OCR Processing
  const processReceiptOCR = async (file) => {
    setIsProcessingOCR(true);
    try {
      const formData = new FormData();
      formData.append('image', file);

      const response = await axios.post('/api/ocr/process', formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });

      if (response.data.success) {
        setOcrResults(response.data.data);
        // Auto-fill form fields
        if (response.data.data.merchant) setValue('merchant', response.data.data.merchant);
        if (response.data.data.amount) setValue('amount', response.data.data.amount);
        if (response.data.data.date) setValue('date', response.data.data.date);
        if (response.data.data.currency) setValue('currency', response.data.data.currency);
        
        toast.success('OCR processing completed! Form auto-filled.');
      } else {
        toast.error('OCR processing failed: ' + response.data.message);
      }
    } catch (error) {
      console.error('OCR error:', error);
      toast.error('Failed to process receipt image');
    } finally {
      setIsProcessingOCR(false);
    }
  };

  // File Upload Handler
  const handleFileUpload = async (event) => {
    const file = event.target.files[0];
    if (!file) return;
    try {
      // Upload to backend (Cloudinary via server)
      const fd = new FormData();
      fd.append('file', file);
      const uploadRes = await axios.post('/api/expenses/upload-receipt', fd, {
        headers: { 'Content-Type': 'multipart/form-data' }
      });

      if (uploadRes.data?.success) {
        setReceiptUpload({ url: uploadRes.data.data.url, name: file.name });
        // If image, trigger OCR for auto-fill
        if (file.type.startsWith('image/')) {
          await processReceiptOCR(file);
        }
        toast.success('Receipt uploaded');
      } else {
        toast.error(uploadRes.data?.message || 'Upload failed');
      }
    } catch (err) {
      console.error('Upload error:', err);
      const msg = err.response?.data?.message || err.message || 'Failed to upload receipt';
      toast.error(msg);
    }
  };

  // Expense Categories
  const categories = [
    'Travel', 'Food', 'Lodging', 'Office Supplies', 'Transportation',
    'Meals', 'Telephone', 'Internet', 'Software', 'Training',
    'Conferences', 'Marketing', 'Other'
  ];

  // Currencies
  const currencies = [
    { code: 'USD', symbol: '$', name: 'US Dollar' },
    { code: 'EUR', symbol: '€', name: 'Euro' },
    { code: 'GBP', symbol: '£', name: 'British Pound' },
    { code: 'INR', symbol: '₹', name: 'Indian Rupee' },
    { code: 'CAD', symbol: 'C$', name: 'Canadian Dollar' },
    { code: 'AUD', symbol: 'A$', name: 'Australian Dollar' },
  ];

  // Submit Expense Mutation
  const submitExpenseMutation = useMutation(
    (expenseData) => axios.post('/api/expenses/create', expenseData),
    {
      onSuccess: () => {
        queryClient.invalidateQueries('dashboard-stats');
        queryClient.invalidateQueries(['expenses', 'my', user._id]);
        toast.success('Expense submitted successfully!');
        reset();
        setReceiptUpload(null);
        setOcrResults(null);
        if (fileInputRef.current) fileInputRef.current.value = '';
      },
      onError: (error) => {
        toast.error(error.response?.data?.message || 'Failed to submit expense');
      }
    }
  );

  const onSubmit = (data) => {
    const tagsArray = data.tags
      ? data.tags
          .split(',')
          .map((t) => t.trim())
          .filter(Boolean)
          .slice(0, 5)
      : undefined;

    const payload = {
      category: data.category,
      description: data.description,
      amount: Number(data.amount),
      currency: data.currency,
      date: data.date,
      merchant: data.merchant || undefined,
      subCategory: data.subCategory || undefined,
      projectCode: data.projectCode || undefined,
      tags: tagsArray,
      receiptUrl: receiptUpload?.url,
      receiptFileName: receiptUpload?.name
    };

    Object.keys(payload).forEach((k) => {
      if (payload[k] === undefined) delete payload[k];
    });

    submitExpenseMutation.mutate(payload);
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Submit Expense</h1>
        <p className="text-gray-600">Upload a receipt or manually enter expense details</p>
      </div>

      <div className="bg-white rounded-lg shadow-sm border">
        <form onSubmit={handleSubmit(onSubmit)} className="p-8">
          {/* OCR Receipt Upload Section */}
          <div className="mb-8">
            <h2 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
              <Zap className="h-5 w-5 mr-2 text-blue-600" />
              Intelligent Receipt Upload
            </h2>
            
            <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center hover:border-blue-400 transition-colors">
              {!receiptUpload ? (
                <div>
                  <FileText className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-gray-900 mb-2">
                    Upload Receipt for Auto-Fill
                  </h3>
                  <p className="text-gray-600 mb-4">
                    AI will extract amount, date, merchant, and currency automatically
                  </p>
                  <div className="flex justify-center space-x-4">
                    <button
                      type="button"
                      onClick={() => fileInputRef.current?.click()}
                      className="btn btn-primary flex items-center"
                    >
                      <Upload className="h-4 w-4 mr-2" />
                      Upload Receipt
                    </button>
                    <button
                      type="button"
                      onClick={() => setValue('manualEntry', true)}
                      className="btn btn-outline flex items-center"
                    >
                      <FileText className="h-4 w-4 mr-2" />
                      Manual Entry
                    </button>
                  </div>
                </div>
              ) : (
                <div>
                  {isProcessingOCR ? (
                    <div>
                      <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
                      <p className="text-blue-600">Processing receipt with AI...</p>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      <div className="flex items-center justify-center space-x-2">
                        <CheckCircle className="h-5 w-5 text-green-500" />
                        <span className="text-green-600">Receipt uploaded successfully!</span>
                      </div>
                      {ocrResults && (
                        <div className="text-left bg-green-50 border border-green-200 rounded-lg p-4">
                          <h4 className="font-medium text-green-900 mb-2">Extracted Information:</h4>
                          <ul className="text-sm text-green-800 space-y-1">
                            {ocrResults.merchant && <li>• Merchant: {ocrResults.merchant}</li>}
                            {ocrResults.amount && <li>• Amount: {ocrResults.currency} {ocrResults.amount}</li>}
                            {ocrResults.date && <li>• Date: {ocrResults.date}</li>}
                          </ul>
                        </div>
                      )}
                      <button
                        type="button"
                        onClick={() => {
                          setReceiptUpload(null);
                          setOcrResults(null);
                          if (fileInputRef.current) fileInputRef.current.value = '';
                        }}
                        className="btn btn-outline btn-sm"
                      >
                        Upload Different Receipt
                      </button>
                    </div>
                  )}
                </div>
              )}
            </div>
            
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*,application/pdf"
              onChange={handleFileUpload}
              className="hidden"
            />
          </div>

          {/* Expense Details Form */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Basic Information */}
            <div className="space-y-6">
              <h3 className="text-lg font-medium text-gray-900">Expense Details</h3>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Category *
                </label>
                <div className="relative">
                  <Building2 className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                  <select
                    {...register('category', { required: 'Category is required' })}
                    className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md focus:ring-1 focus:ring-blue-500 focus:border-blue-500"
                  >
                    <option value="">Select category</option>
                    {categories.map(category => (
                      <option key={category} value={category}>{category}</option>
                    ))}
                  </select>
                </div>
                {errors.category && (
                  <p className="mt-1 text-sm text-red-600">{errors.category.message}</p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Description *
                </label>
                <textarea
                  {...register('description', {
                    required: 'Description is required',
                    minLength: { value: 5, message: 'Description must be at least 5 characters' }
                  })}
                  rows={3}
                  className="block w-full border border-gray-300 rounded-md focus:ring-1 focus:ring-blue-500 focus:border-blue-500"
                  placeholder="Brief description of the expense"
                />
                {errors.email && (
                  <p className="mt-1 text-sm text-red-600">{errors.email.message}</p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Merchant/Vendor
                </label>
                <div className="relative">
                  <MapPin className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                  <input
                    {...register('merchant')}
                    type="text"
                    className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md focus:ring-1 focus:ring-blue-500 focus:border-blue-500"
                    placeholder="e.g., Amazon, Uber, Restaurant"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Expense Date *
                </label>
                <div className="relative">
                  <Calendar className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                  <input
                    {...register('date', { required: 'Date is required' })}
                    type="date"
                    max={new Date().toISOString().split('T')[0]}
                    className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md focus:ring-1 focus:ring-blue-500 focus:border-blue-500"
                  />
                </div>
                {errors.date && (
                  <p className="mt-1 text-sm text-red-600">{errors.date.message}</p>
                )}
              </div>
            </div>

            {/* Financial Information */}
            <div className="space-y-6">
              <h3 className="text-lg font-medium text-gray-900">Financial Information</h3>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Amount *
                  </label>
                  <div className="relative">
                    <DollarSign className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                    <input
                      {...register('amount', {
                        required: 'Amount is required',
                        min: { value: 0.01, message: 'Amount must be Greater than 0' },
                        pattern: {
                          value: /^\d+(\.\d{1,2})?$/,
                          message: 'Invalid amount format'
                        }
                      })}
                      type="number"
                      step="0.01"
                      min="0.01"
                      className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md focus:ring-1 focus:ring-blue-500 focus:border-blue-500"
                      placeholder="0.00"
                    />
                  </div>
                  {errors.amount && (
                    <p className="mt-1 text-sm text-red-600">{errors.amount.message}</p>
                  )}
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Currency *
                  </label>
                  <select
                    {...register('currency', { required: 'Currency is required' })}
                    className="block w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-1 focus:ring-blue-500 focus:border-blue-500"
                  >
                    <option value="">Select currency</option>
                    {currencies.map(curr => (
                      <option key={curr.code} value={curr.code}>
                        {curr.code} - {curr.symbol} {curr.name}
                      </option>
                    ))}
                  </select>
                  {errors.currency && (
                    <p className="mt-1 text-sm text-red-600">{errors.currency.message}</p>
                  )}
                </div>
              </div>

              {/* Currency Conversion Preview */}
              {watchedValues.amount && watchedValues.currency && watchedValues.currency !== user?.companyId?.currency && (
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                  <div className="flex items-center mb-2">
                    <AlertCircle className="h-4 w-4 text-blue-600 mr-2" />
                    <span className="text-sm font-medium text-blue-900">Automatic Converter</span>
                  </div>
                  <p className="text-sm text-blue-800">
                    {watchedValues.currency} {watchedValues.amount} will be converted to your company's base currency ({user?.companyId?.currency})
                  </p>
                </div>
              )}

              {/* Additional Fields */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Project Code
                  </label>
                  <input
                    {...register('projectCode')}
                    type="text"
                    className="block w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-1 focus:ring-blue-500 focus:border-blue-500"
                    placeholder="e.g., PROJ-2024"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Sub-category
                  </label>
                  <input
                    {...register('subCategory')}
                    type="text"
                    className="block w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-1 focus:ring-blue-500 focus:border-blue-500"
                    placeholder="More specific category"
                  />
                </div>
              </div>

              {/* Tags */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Tags (comma-separated)
                </label>
                <input
                  {...register('tags')}
                  type="text"
                  className="block w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-1 focus:ring-blue-500 focus:border-blue-500"
                  placeholder="urgent, client-meeting, travel"
                />
                <p className="mt-1 text-sm text-gray-500">
                  Separate multiple tags with commas
                </p>
              </div>
            </div>
          </div>

          {/* Submit Button */}
          <div className="flex justify-end pt-6 border-t mt-8">
            <button
              type="submit"
              disabled={submitExpenseMutation.isLoading}
              className="btn btn-primary btn-lg"
            >
              {submitExpenseMutation.isLoading ? (
                <div className="flex items-center">
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                  Submitting Expense...
                </div>
              ) : (
                <div className="flex items-center">
                  <CheckCircle className="h-4 w-4 mr-2" />
                  Submit Expense
                </div>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default ExpenseSubmissionForm;
